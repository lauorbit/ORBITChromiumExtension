"use strict";

const LOOKUP_TIMEOUT_MS = 12000;
const crossrefCache = new Map();

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== "ORBIT_CROSSREF_LOOKUP") {
    return undefined;
  }

  lookupCrossref(message.payload)
    .then((result) => sendResponse({ ok: true, result }))
    .catch((error) => sendResponse({ ok: false, error: error.message }));

  return true;
});

async function lookupCrossref(payload) {
  const cacheKey = JSON.stringify(payload ?? {});
  if (crossrefCache.has(cacheKey)) {
    return crossrefCache.get(cacheKey);
  }

  const lookupPromise = performLookup(payload).catch((error) => {
    crossrefCache.delete(cacheKey);
    throw error;
  });

  crossrefCache.set(cacheKey, lookupPromise);
  return lookupPromise;
}

async function performLookup(payload) {
  const title = cleanText(payload?.title);
  if (!title) {
    return null;
  }

  const metadata = cleanText(payload?.metadata);
  const author = cleanText(payload?.author);
  const year = normalizeYear(payload?.year);

  const query = [title, metadata].filter(Boolean).join(" ");
  const url = new URL("https://api.crossref.org/works");
  url.searchParams.set("query.bibliographic", query);
  url.searchParams.set("rows", "5");
  url.searchParams.set(
    "select",
    "DOI,container-title,ISSN,title,published,published-print,published-online,author"
  );

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), LOOKUP_TIMEOUT_MS);

  try {
    const response = await fetch(url.toString(), {
      signal: controller.signal,
      headers: {
        Accept: "application/json"
      }
    });

    if (!response.ok) {
      throw new Error(`Crossref request failed with ${response.status}`);
    }

    const json = await response.json();
    const items = Array.isArray(json?.message?.items) ? json.message.items : [];
    if (!items.length) {
      return null;
    }

    const best = pickBestCrossrefItem(items, { title, author, year });
    if (!best) {
      return null;
    }

    return {
      containerTitle: firstString(best["container-title"]),
      issns: Array.isArray(best.ISSN) ? best.ISSN : [],
      doi: cleanText(best.DOI)
    };
  } finally {
    clearTimeout(timeoutId);
  }
}

function pickBestCrossrefItem(items, query) {
  const scored = items
    .map((item) => ({ item, score: scoreCrossrefItem(item, query) }))
    .filter(({ score }) => Number.isFinite(score))
    .sort((left, right) => right.score - left.score);

  return scored.length ? scored[0].item : null;
}

function scoreCrossrefItem(item, query) {
  const containerTitle = cleanText(firstString(item?.["container-title"]));
  if (!containerTitle) {
    return Number.NEGATIVE_INFINITY;
  }

  const itemTitle = cleanText(firstString(item?.title));
  const queryTitleNorm = normalizeText(query.title);
  const itemTitleNorm = normalizeText(itemTitle);
  const authorNorm = normalizeText(query.author);
  const itemYear = extractCrossrefYear(item);

  let score = 0;
  score += titleSimilarity(queryTitleNorm, itemTitleNorm) * 100;

  if (item?.ISSN?.length) {
    score += 5;
  }

  if (authorNorm && Array.isArray(item?.author)) {
    const hasAuthorMatch = item.author.some((candidate) => {
      const family = normalizeText(candidate?.family);
      return family && family === authorNorm;
    });
    if (hasAuthorMatch) {
      score += 12;
    }
  }

  if (query.year && itemYear) {
    if (itemYear === query.year) {
      score += 12;
    } else if (Math.abs(itemYear - query.year) === 1) {
      score += 5;
    } else {
      score -= 6;
    }
  }

  if (normalizeText(containerTitle) === "SSRN ELECTRONIC JOURNAL") {
    score -= 20;
  }

  return score;
}

function titleSimilarity(left, right) {
  if (!left || !right) {
    return 0;
  }
  if (left === right) {
    return 1;
  }

  const leftTokens = new Set(left.split(" ").filter(Boolean));
  const rightTokens = new Set(right.split(" ").filter(Boolean));
  if (!leftTokens.size || !rightTokens.size) {
    return 0;
  }

  let intersection = 0;
  for (const token of leftTokens) {
    if (rightTokens.has(token)) {
      intersection += 1;
    }
  }

  return intersection / Math.max(leftTokens.size, rightTokens.size);
}

function extractCrossrefYear(item) {
  const parts =
    item?.published?.["date-parts"] ??
    item?.["published-print"]?.["date-parts"] ??
    item?.["published-online"]?.["date-parts"];

  const year = Array.isArray(parts) && Array.isArray(parts[0]) ? Number(parts[0][0]) : null;
  return Number.isInteger(year) ? year : null;
}

function normalizeText(value) {
  return cleanText(value)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase()
    .replace(/&/g, " AND ")
    .replace(/[^A-Z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/^THE /, "");
}

function cleanText(value) {
  return typeof value === "string" ? value.replace(/\s+/g, " ").trim() : "";
}

function firstString(value) {
  return Array.isArray(value) && value.length ? String(value[0]) : "";
}

function normalizeYear(value) {
  const numeric = Number(value);
  return Number.isInteger(numeric) ? numeric : null;
}
