"use strict";

(() => {
  if (window.__orbitScholarLoaded) {
    return;
  }
  window.__orbitScholarLoaded = true;

  const dataset = globalThis.ORBIT_DATASET;
  if (!dataset?.entries || !dataset?.titleIndex || !dataset?.issnIndex) {
    console.warn("ORBIT Scholar extension: dataset missing or malformed.");
    return;
  }

  const DETAIL_LABELS = Array.isArray(dataset.detailLabels)
    ? dataset.detailLabels
    : ["ABDC", "JUFO", "AJG", "FNEGE", "VHB", "Norwegian"];
  const FLAG_ELITE = dataset.flagLabels?.elite ?? 1;
  const FLAG_WARNING = dataset.flagLabels?.warning ?? 2;

  const processedAttribute = "data-orbit-processed";
  const resolutionCache = new Map();
  const scholarVenueCache = new Map();
  const scholarCitationDetailCache = new Map();
  const runNetworkTask = createLimiter(3);

  processDocument();
  observeDocument();

  function observeDocument() {
    let timerId = 0;
    const observer = new MutationObserver(() => {
      clearTimeout(timerId);
      timerId = window.setTimeout(processDocument, 250);
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }

  function processDocument() {
    for (const item of collectSearchResults()) {
      if (!item.hasAttribute(processedAttribute)) {
        item.setAttribute(processedAttribute, "true");
        void annotateSearchResult(item);
      }
    }

    for (const row of collectCitationRows()) {
      if (!row.hasAttribute(processedAttribute)) {
        row.setAttribute(processedAttribute, "true");
        void annotateCitationRow(row);
      }
    }
  }

  function collectSearchResults() {
    return Array.from(document.querySelectorAll("#gs_res_ccl_mid .gs_ri"));
  }

  function collectCitationRows() {
    return Array.from(document.querySelectorAll("tr.gsc_a_tr"));
  }

  async function annotateSearchResult(resultNode) {
    const heading = resultNode.querySelector("h3.gs_rt");
    if (!heading) {
      return;
    }

    const titleNode = heading.querySelector("a") ?? heading;
    const title = cleanText(titleNode.textContent);
    if (!title) {
      return;
    }

    const metadata = cleanText(resultNode.querySelector(".gs_a")?.textContent);
    const scholarId = titleNode.id || "";
    const cluster = mountCluster(titleNode);
    setClusterLoading(cluster);

    const resolution = await resolveJournal({
      title,
      metadata,
      author: extractFirstAuthorSurname(metadata),
      year: extractYear(metadata),
      scholarId,
      detailUrl: ""
    });

    renderResolution(cluster, resolution);
  }

  async function annotateCitationRow(rowNode) {
    const titleNode = rowNode.querySelector("td.gsc_a_t > a");
    if (!titleNode) {
      return;
    }

    const title = cleanText(titleNode.textContent);
    if (!title) {
      return;
    }

    const grayNodes = rowNode.querySelectorAll("td.gsc_a_t .gs_gray");
    const authorLine = cleanText(grayNodes[0]?.textContent);
    const venueLine = cleanText(grayNodes[1]?.textContent);
    const metadata = [authorLine, venueLine].filter(Boolean).join(" - ");
    const cluster = mountCluster(titleNode);
    setClusterLoading(cluster);

    const resolution = await resolveJournal({
      title,
      metadata,
      author: extractFirstAuthorSurname(authorLine),
      year: extractYear(rowNode.querySelector("td.gsc_a_y")?.textContent),
      scholarId: "",
      detailUrl: titleNode.getAttribute("href") || ""
    });

    renderResolution(cluster, resolution);
  }

  async function resolveJournal(details) {
    const cacheKey = JSON.stringify(details);
    if (resolutionCache.has(cacheKey)) {
      return resolutionCache.get(cacheKey);
    }

    const promise = (async () => {
      const inlineMatch = resolveFromCandidates(
        extractVenueCandidates(details.metadata),
        "Google Scholar metadata"
      );
      if (inlineMatch) {
        return inlineMatch;
      }

      if (details.detailUrl) {
        const citationDetail = await fetchScholarCitationDetail(details.detailUrl);
        if (citationDetail?.source) {
          const detailMatch = resolveFromCandidates(
            deriveVenueVariants(citationDetail.source),
            "Google Scholar article page"
          );
          if (detailMatch) {
            return detailMatch;
          }
        }
      }

      if (details.scholarId) {
        const scholarVenue = await fetchScholarCitationVenue(details.scholarId);
        if (scholarVenue) {
          const scholarMatch = resolveFromCandidates(
            deriveVenueVariants(scholarVenue),
            "Google Scholar citation export"
          );
          if (scholarMatch) {
            return scholarMatch;
          }
        }
      }

      const crossref = await lookupCrossref(details);
      if (crossref?.issns?.length) {
        const issnMatch = matchByIssn(crossref.issns);
        if (issnMatch) {
          return enrichMatch(issnMatch, {
            sourceLabel: "Crossref ISSN",
            matchedValue: crossref.containerTitle || issnMatch.title
          });
        }
      }

      if (crossref?.containerTitle) {
        const titleMatch = resolveFromCandidates(
          deriveVenueVariants(crossref.containerTitle),
          "Crossref journal title"
        );
        if (titleMatch) {
          return titleMatch;
        }
      }

      return null;
    })();

    resolutionCache.set(cacheKey, promise);
    return promise;
  }

  function resolveFromCandidates(candidates, sourceLabel) {
    for (const candidate of candidates) {
      const match = matchByTitle(candidate);
      if (match) {
        return enrichMatch(match, { sourceLabel, matchedValue: candidate });
      }
    }
    return null;
  }

  function enrichMatch(match, extra) {
    return {
      ...match,
      detailPairs: buildDetailPairs(match.details),
      isElite: (match.flags & FLAG_ELITE) !== 0,
      isWarning: (match.flags & FLAG_WARNING) !== 0,
      ...extra
    };
  }

  function buildDetailPairs(details) {
    return DETAIL_LABELS.map((label, index) => [label, details[index] || ""]).filter(
      ([, value]) => Boolean(value)
    );
  }

  function matchByIssn(issns) {
    for (const rawIssn of issns) {
      const normalizedIssn = normalizeIssn(rawIssn);
      if (!normalizedIssn) {
        continue;
      }

      const entryId = dataset.issnIndex[normalizedIssn];
      if (entryId === undefined) {
        continue;
      }

      return hydrateEntry(dataset.entries[entryId]);
    }

    return null;
  }

  function matchByTitle(title) {
    for (const variant of buildTitleVariants(title)) {
      const entryId = dataset.titleIndex[variant];
      if (entryId === undefined) {
        continue;
      }

      return hydrateEntry(dataset.entries[entryId]);
    }

    return null;
  }

  function hydrateEntry(entry) {
    if (!Array.isArray(entry) || entry.length < 2) {
      return null;
    }

    return {
      title: entry[0],
      grade: entry[1],
      flags: Number(entry[2] || 0),
      details: Array.isArray(entry[3]) ? entry[3] : []
    };
  }

  async function fetchScholarCitationVenue(scholarId) {
    if (scholarVenueCache.has(scholarId)) {
      return scholarVenueCache.get(scholarId);
    }

    const promise = runNetworkTask(async () => {
      const url = new URL("/scholar", window.location.origin);
      url.searchParams.set("q", `info:${scholarId}:scholar.google.com/`);
      url.searchParams.set("output", "cite");
      url.searchParams.set("scirp", "0");
      url.searchParams.set("hl", document.documentElement.lang || "en");

      const response = await fetch(url.toString(), {
        credentials: "same-origin"
      });

      if (!response.ok) {
        return null;
      }

      const html = await response.text();
      const match = html.match(/<i>([^<]+)<\/i>/i);
      return match ? decodeHtml(match[1]) : null;
    }).catch(() => null);

    scholarVenueCache.set(scholarId, promise);
    return promise;
  }

  async function fetchScholarCitationDetail(detailUrl) {
    const url = new URL(detailUrl, window.location.origin).toString();
    if (scholarCitationDetailCache.has(url)) {
      return scholarCitationDetailCache.get(url);
    }

    const promise = runNetworkTask(async () => {
      const response = await fetch(url, {
        credentials: "same-origin"
      });

      if (!response.ok) {
        return null;
      }

      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, "text/html");
      const rows = Array.from(doc.querySelectorAll("#gsc_oci_table .gs_scl"));
      const fields = {};

      for (const row of rows) {
        const field = cleanText(row.querySelector(".gsc_oci_field")?.textContent);
        const value = cleanText(row.querySelector(".gsc_oci_value")?.textContent);
        if (field && value) {
          fields[field.toLowerCase()] = value;
        }
      }

      return {
        source: fields.source || "",
        publicationDate: fields["publication date"] || ""
      };
    }).catch(() => null);

    scholarCitationDetailCache.set(url, promise);
    return promise;
  }

  async function lookupCrossref(details) {
    return runNetworkTask(
      () =>
        new Promise((resolve) => {
          chrome.runtime.sendMessage(
            {
              type: "ORBIT_CROSSREF_LOOKUP",
              payload: details
            },
            (response) => {
              if (chrome.runtime.lastError || !response?.ok) {
                resolve(null);
                return;
              }
              resolve(response.result ?? null);
            }
          );
        })
    );
  }

  function mountCluster(anchorNode) {
    let cluster = anchorNode.parentElement?.querySelector(":scope > .orbit-badge-cluster");
    if (cluster) {
      return cluster;
    }

    cluster = document.createElement("span");
    cluster.className = "orbit-badge-cluster";
    anchorNode.insertAdjacentElement("afterend", cluster);
    return cluster;
  }

  function setClusterLoading(cluster) {
    cluster.replaceChildren(createMainBadge("ORBIT ...", "orbit-loading"));
  }

  function renderResolution(cluster, resolution) {
    if (!resolution) {
      cluster.remove();
      return;
    }

    const gradeClass = `orbit-grade-${resolution.grade.toLowerCase().replace("+", "plus")}`;
    const mainBadge = createMainBadge(`ORBIT ${resolution.grade}`, gradeClass);
    mainBadge.appendChild(buildTooltip(resolution));
    cluster.replaceChildren(mainBadge);

    if (resolution.isElite) {
      cluster.appendChild(createFlagBadge("Elite", "orbit-flag-elite"));
    }
    if (resolution.isWarning) {
      cluster.appendChild(createFlagBadge("Warning", "orbit-flag-warning"));
    }
  }

  function createMainBadge(label, className) {
    const badge = document.createElement("span");
    badge.className = `orbit-badge ${className}`;
    badge.textContent = label;
    return badge;
  }

  function createFlagBadge(label, className) {
    const badge = document.createElement("span");
    badge.className = `orbit-flag ${className}`;
    badge.textContent = label;
    return badge;
  }

  function buildTooltip(resolution) {
    const tooltip = document.createElement("span");
    tooltip.className = "orbit-tooltip";

    const title = document.createElement("span");
    title.className = "orbit-tooltip-title";
    title.textContent = resolution.title;
    tooltip.appendChild(title);

    tooltip.appendChild(createTooltipLine(`ORBIT: ${resolution.grade}`));

    for (const [label, value] of resolution.detailPairs) {
      tooltip.appendChild(createTooltipLine(`${label}: ${value}`));
    }

    if (resolution.isElite) {
      tooltip.appendChild(createTooltipLine("Elite journal"));
    }
    if (resolution.isWarning) {
      tooltip.appendChild(createTooltipLine("Warning list"));
    }

    if (resolution.sourceLabel) {
      tooltip.appendChild(
        createTooltipLine(
          `Matched via ${resolution.sourceLabel}${resolution.matchedValue ? `: ${resolution.matchedValue}` : ""}`
        )
      );
    }

    return tooltip;
  }

  function createTooltipLine(text) {
    const line = document.createElement("span");
    line.className = "orbit-tooltip-line";
    line.textContent = text;
    return line;
  }

  function extractVenueCandidates(metadata) {
    if (!metadata) {
      return [];
    }

    const candidates = new Set();
    const parts = metadata
      .replace(/\u00a0/g, " ")
      .split(/\s+-\s+/)
      .map((part) => cleanText(part))
      .filter(Boolean);

    if (parts.length >= 2) {
      addCandidateVariants(parts[1], candidates);
    }

    if (parts.length >= 3) {
      addCandidateVariants(parts[2], candidates);
    }

    if (!parts.length) {
      addCandidateVariants(metadata, candidates);
    }

    return Array.from(candidates);
  }

  function addCandidateVariants(value, target) {
    for (const candidate of deriveVenueVariants(value)) {
      if (candidate.length >= 3) {
        target.add(candidate);
      }
    }
  }

  function deriveVenueVariants(value) {
    const cleaned = cleanText(value)
      .replace(/^[^A-Za-z0-9]+/, "")
      .replace(/\s+/g, " ");
    if (!cleaned) {
      return [];
    }

    const variants = new Set([cleaned]);
    const noTrailingCommaSegment = cleaned.replace(/,\s*[^,]+$/u, "").trim();
    if (noTrailingCommaSegment) {
      variants.add(noTrailingCommaSegment);
    }

    const trimmedOriginal = trimTrailingVenueNumbers(cleaned);
    if (trimmedOriginal) {
      variants.add(trimmedOriginal);
    }

    const trimmedComma = trimTrailingVenueNumbers(noTrailingCommaSegment);
    if (trimmedComma) {
      variants.add(trimmedComma);
    }

    const colonIndex = cleaned.indexOf(":");
    if (colonIndex > 0) {
      variants.add(cleaned.slice(0, colonIndex).trim());
    }

    return Array.from(variants).filter(Boolean);
  }

  function trimTrailingVenueNumbers(value) {
    let current = cleanText(value);
    const patterns = [
      /\s+\d{4}\s*\([^)]*\)$/u,
      /\s+\d+\s*\([^)]*\)$/u,
      /\s+\d{4}$/u,
      /\s+\d+[A-Za-z]?$/u
    ];

    let changed = true;
    while (changed) {
      changed = false;
      for (const pattern of patterns) {
        const next = current.replace(pattern, "").trim();
        if (next && next !== current) {
          current = next;
          changed = true;
        }
      }
    }

    return current;
  }

  function buildTitleVariants(value) {
    const variants = new Set();
    for (const candidate of deriveVenueVariants(value)) {
      const normalized = normalizeTitle(candidate);
      if (normalized) {
        variants.add(normalized);
      }
    }
    return Array.from(variants);
  }

  function normalizeTitle(value) {
    return cleanText(value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toUpperCase()
      .replace(/&/g, " AND ")
      .replace(/[^A-Z0-9]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/^THE /, "");
  }

  function normalizeIssn(value) {
    const normalized = cleanText(value).toUpperCase().replace(/[^0-9X]/g, "");
    return normalized.length >= 8 ? normalized : "";
  }

  function extractFirstAuthorSurname(value) {
    const firstAuthor = cleanText(value).split(",")[0];
    if (!firstAuthor) {
      return "";
    }
    const parts = firstAuthor.split(/\s+/).filter(Boolean);
    return parts.length ? parts[parts.length - 1] : "";
  }

  function extractYear(value) {
    const match = cleanText(value).match(/\b(19|20)\d{2}\b/);
    return match ? Number(match[0]) : null;
  }

  function decodeHtml(value) {
    const element = document.createElement("textarea");
    element.innerHTML = value;
    return cleanText(element.value);
  }

  function cleanText(value) {
    return typeof value === "string" ? value.replace(/\s+/g, " ").trim() : "";
  }

  function createLimiter(limit) {
    let active = 0;
    const queue = [];

    const runNext = () => {
      if (active >= limit || !queue.length) {
        return;
      }

      const next = queue.shift();
      active += 1;

      Promise.resolve()
        .then(next.task)
        .then(next.resolve, next.reject)
        .finally(() => {
          active -= 1;
          runNext();
        });
    };

    return (task) =>
      new Promise((resolve, reject) => {
        queue.push({ task, resolve, reject });
        runNext();
      });
  }
})();
