#!/usr/bin/env python3
"""Build a compact ORBIT lookup for the Scholar extension."""

from __future__ import annotations

import argparse
import json
import re
import unicodedata
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

DETAIL_COLUMNS = [
    ("ABDC", "ABDC: 2025 rating"),
    ("JUFO", "JUFO: Level"),
    ("AJG", "AJG: Grade (Converted)"),
    ("FNEGE", "FNEGE: FNEGE_2025"),
    ("VHB", "VHB: Grade (Converted)"),
    ("Norwegian", "Norwegian Level"),
]

FLAG_ELITE = 1
FLAG_WARNING = 2


def split_titles(value: object) -> list[str]:
    if pd.isna(value):
        return []

    titles: list[str] = []
    seen: set[str] = set()
    for part in str(value).split("|"):
        title = re.sub(r"\s+", " ", part).strip(" ;")
        if not title:
            continue
        key = title.casefold()
        if key in seen:
            continue
        seen.add(key)
        titles.append(title)
    return titles


def split_issns(value: object) -> list[str]:
    if pd.isna(value):
        return []

    issns: list[str] = []
    seen: set[str] = set()
    for part in re.split(r"[|,;/]+", str(value)):
        token = re.sub(r"[^0-9Xx]", "", part).upper()
        if len(token) < 8 or token in seen:
            continue
        seen.add(token)
        issns.append(token)
    return issns


def normalize_title(value: str) -> str:
    normalized = unicodedata.normalize("NFD", value)
    normalized = normalized.encode("ascii", "ignore").decode("ascii")
    normalized = normalized.upper()
    normalized = normalized.replace("&", " AND ")
    normalized = re.sub(r"[^A-Z0-9]+", " ", normalized)
    normalized = re.sub(r"\s+", " ", normalized).strip()
    normalized = re.sub(r"^THE ", "", normalized)
    return normalized


def split_scopus_issns(*values: object) -> list[str]:
    tokens: list[str] = []
    seen: set[str] = set()
    for value in values:
        if pd.isna(value):
            continue
        token = re.sub(r"[^0-9Xx]", "", str(value)).upper()
        if len(token) < 8 or token in seen:
            continue
        seen.add(token)
        tokens.append(token)
    return tokens


def truthy(value: object) -> bool:
    if pd.isna(value):
        return False
    return str(value).strip().lower() in {"yes", "true", "1", "y"}


def detail_value(value: object) -> str:
    if pd.isna(value):
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def load_scopus_index(scopus_path: Path | None) -> dict[str, dict[str, set[str]]]:
    if scopus_path is None:
        return {}

    dataframe = pd.read_excel(scopus_path, usecols=["Source Title", "ISSN", "EISSN"])
    index: dict[str, dict[str, set[str]]] = {}

    for _, row in dataframe.iterrows():
        title = str(row["Source Title"]).strip() if not pd.isna(row["Source Title"]) else ""
        if not title:
            continue

        key = normalize_title(title)
        bucket = index.setdefault(key, {"titles": set(), "issns": set()})
        bucket["titles"].add(title)
        bucket["issns"].update(split_scopus_issns(row["ISSN"], row["EISSN"]))

    return index


def build_payload(input_path: Path, scopus_path: Path | None = None) -> dict[str, object]:
    dataframe = pd.read_excel(
        input_path,
        usecols=[
            "Journal Title",
            "ISSN",
            "ORBIT_Grade",
            "Is Elite Journal",
            "Is Warning Journal",
            *[column for _, column in DETAIL_COLUMNS],
        ],
    )
    dataframe = dataframe[dataframe["ORBIT_Grade"].notna()].copy()
    scopus_index = load_scopus_index(scopus_path.resolve() if scopus_path else None)
    unified_title_counts: dict[str, int] = defaultdict(int)

    for value in dataframe["Journal Title"]:
        for title in split_titles(value):
            normalized = normalize_title(title)
            if normalized:
                unified_title_counts[normalized] += 1

    entries: list[list[str]] = []
    alias_to_ids: dict[str, set[int]] = defaultdict(set)
    issn_index: dict[str, int] = {}
    ambiguous_issns: set[str] = set()
    scopus_title_matches = 0
    scopus_issn_merges = 0

    for _, row in dataframe.iterrows():
        titles = split_titles(row["Journal Title"])
        if not titles:
            continue

        primary_title = titles[0]
        grade = str(row["ORBIT_Grade"]).strip()
        flags = 0
        if truthy(row["Is Elite Journal"]):
            flags |= FLAG_ELITE
        if truthy(row["Is Warning Journal"]):
            flags |= FLAG_WARNING

        details = [detail_value(row[column]) for _, column in DETAIL_COLUMNS]
        entry_id = len(entries)
        entries.append([primary_title, grade, flags, details])

        seen_scopus_keys: set[str] = set()
        all_titles = list(titles)
        scopus_issns: set[str] = set()

        for title in titles:
            normalized = normalize_title(title)
            if normalized:
                alias_to_ids[normalized].add(entry_id)
                if (
                    normalized not in seen_scopus_keys
                    and normalized in scopus_index
                    and unified_title_counts.get(normalized, 0) == 1
                ):
                    seen_scopus_keys.add(normalized)
                    scopus_title_matches += 1
                    all_titles.extend(sorted(scopus_index[normalized]["titles"]))
                    scopus_issns.update(scopus_index[normalized]["issns"])

        for title in all_titles:
            normalized = normalize_title(title)
            if normalized:
                alias_to_ids[normalized].add(entry_id)

        all_issns = sorted(scopus_issns) if scopus_issns else split_issns(row["ISSN"])
        if scopus_issns:
            scopus_issn_merges += len(scopus_issns)

        for issn in sorted(set(all_issns)):
            if issn in ambiguous_issns:
                continue

            existing = issn_index.get(issn)
            if existing is None:
                issn_index[issn] = entry_id
                continue

            if existing != entry_id:
                ambiguous_issns.add(issn)
                issn_index.pop(issn, None)

    title_index = {
        alias: next(iter(ids))
        for alias, ids in alias_to_ids.items()
        if len(ids) == 1
    }

    ambiguous_title_count = sum(1 for ids in alias_to_ids.values() if len(ids) > 1)

    return {
        "builtAt": datetime.now(timezone.utc).isoformat(),
        "sourceWorkbook": str(input_path),
        "sourceScopus": str(scopus_path) if scopus_path else "",
        "detailLabels": [label for label, _ in DETAIL_COLUMNS],
        "flagLabels": {
            "elite": FLAG_ELITE,
            "warning": FLAG_WARNING,
        },
        "stats": {
            "entries": len(entries),
            "uniqueTitleKeys": len(title_index),
            "issnKeys": len(issn_index),
            "ambiguousTitleKeysSkipped": ambiguous_title_count,
            "ambiguousIssnKeysSkipped": len(ambiguous_issns),
            "scopusTitleMatches": scopus_title_matches,
            "scopusIssnsMerged": scopus_issn_merges,
        },
        "entries": entries,
        "titleIndex": title_index,
        "issnIndex": issn_index,
    }


def main() -> None:
    extension_dir = Path(__file__).resolve().parents[1]
    repo_root = extension_dir.parent
    default_input = (
        repo_root
        / "Scripts"
        / "ORBITResult_20260414_154306"
        / "databases"
        / "Unified_Journals.xlsx"
    )
    default_scopus = repo_root / "Scripts" / "ScopusListFeb2026.xlsx"
    default_output = extension_dir / "data" / "orbit-dataset.js"

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=default_input)
    parser.add_argument("--scopus", type=Path, default=default_scopus)
    parser.add_argument("--output", type=Path, default=default_output)
    args = parser.parse_args()

    payload = build_payload(
        input_path=args.input.resolve(),
        scopus_path=args.scopus.resolve() if args.scopus else None,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)

    serialized = json.dumps(payload, ensure_ascii=True, separators=(",", ":"))
    args.output.write_text(
        "// Auto-generated by tools/build_orbit_dataset.py\n"
        f"globalThis.ORBIT_DATASET={serialized};\n",
        encoding="utf-8",
    )

    print(
        "Wrote ORBIT dataset with "
        f"{payload['stats']['entries']} graded journals to {args.output}"
    )


if __name__ == "__main__":
    main()
